# Job4j_design

## Contents

- Maven
- AsserJ
- Iterator
- Generic
- List
- Set
- Map
- Tree
- Контрольные вопросы
- Ввод-вывод
- Socket
- Логгирование
- Сериализация
- Контрольные вопросы
- Настройка PostgreSQL
- Create Update Insert
- Query
- Outer join
- Объекты базы данных
- JDBC
- Liquibase
- Проект. Агрегатор Java вакансий
- Контрольные вопросы
- Понятие сборщик мусора
- Виды сборщиков мусора
- Профилирование приложения
- Типы ссылок и коллекции на soft weak ссылках
- Java Memory Model
- Контрольные вопросы
- TDD
- SRP
- OCP
- LSP
- ISP
- DIP
- Контрольные вопросы
