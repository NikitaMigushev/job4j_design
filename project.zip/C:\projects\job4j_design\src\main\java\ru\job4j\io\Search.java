package ru.job4j.io;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.function.Predicate;

public class Search {
    public static void main(String[] args) throws IOException {
        validateArgs(args);
        Path start = Paths.get(args[0]);
        search(start, p -> p.toFile().getName().endsWith(args[1])).forEach(System.out::println);
    }

    public static List<Path> search(Path root, Predicate<Path> condition) {
        SearchFiles searcher = new SearchFiles(condition);
        try {
            Files.walkFileTree(root, searcher);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return searcher.getPaths();
    }

    private static void validateArgs(String[] args) {
        if (args.length < 2) {
            throw new IllegalArgumentException("Program arguments are missing. First argument is Root folder is missing "
                    + "or Second argument is file extention to be searched is missing");
        }
        Path path = Paths.get(args[0]);
        if (!Files.isDirectory(path)) {
            throw new IllegalArgumentException("First argument Root folder is invalid");
        }
        if (!args[1].startsWith(".")) {
            throw new IllegalArgumentException("Second argument File extension is not valid.");
        }
    }
}
