package ru.job4j.set;

public class Practice {
    public static void main(String[] args) {
        System.out.println();

    }
}
